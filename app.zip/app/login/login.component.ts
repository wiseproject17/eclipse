import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  customer : any; 
  user: any;
  constructor(private router: Router, private customerService: CustomerService) {
    this.user = {loginId: '', password: ''};
  }
  ngOnInit() {
  }
  // userLogin(): void {
  //   console.log('Inside user Login method...');
  //   console.log(this.user);
  // }

  loginSubmit(loginForm: any): void { 

    this.customerService.getCustomerByUserPass(loginForm.loginId , loginForm.password).subscribe((result: any) => {
      this.customer = result; 
      if(this.customer == null){
        alert('Invalid Credentials..');
      }
      else{
        this.customerService.setUserLoggedIn();
        alert('login successful');
        this.router.navigate(['register']);
      }
     
    });
  }

}

