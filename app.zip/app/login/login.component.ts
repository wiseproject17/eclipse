import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { ViewChild,ElementRef } from '@angular/core'


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  @ViewChild('loginRef', {static: true })
 loginElement: ElementRef;
  customer : any;
  user: any;
  agent: any;
  auth2: any;
  constructor(private router: Router, private customerService: CustomerService) {
    this.user = {loginId: '', password: ''};
  }
  ngOnInit() {
    this.googleInitialize();
  }


  AgentloginSubmit(AgentloginForm: any): void {

    this.customerService.getAgentByUserPass(AgentloginForm.loginId , AgentloginForm.password).subscribe((result: any) => {
      this.agent = result;
      if(this.agent == null){
        alert('Invalid Credentials..');
      }
      else{
        this.customerService.setUserLoggedIn();
        alert('login successful');
        localStorage.setItem('user', JSON.stringify(this.agent));
        this.router.navigate(['agentProduct']);
      }
    });
  }
  loginSubmit(loginForm: any): void {

    this.customerService.getCustomerByUserPass(loginForm.loginId , loginForm.password).subscribe((result: any) => {
      this.customer = result;
      if(this.customer == null){
        alert('Invalid Credentials..');
      }
      else{
        this.customerService.setUserLoggedIn();
        alert('login successful');
        localStorage.setItem('user', JSON.stringify(this.customer));
        this.router.navigate(['product']);
      }
    });
  }
  googleInitialize() {
    window['googleSDKLoaded'] = () => {
      window['gapi'].load('auth2', () => {
        this.auth2 = window['gapi'].auth2.init({
          client_id: '959702635984-ddrmm93dtuq6vssau059bk45sdbg9olm.apps.googleusercontent.com',
          cookie_policy: 'single_host_origin',
          scope: 'profile email'
        });
        this.prepareLogin();
      });
    }
    (function(d, s, id){
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) {return;}
      js = d.createElement(s); js.id = id;
      js.src = "https://apis.google.com/js/platform.js?onload=googleSDKLoaded";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'google-jssdk'));
  }

  prepareLogin() {
    this.auth2.attachClickHandler(this.loginElement.nativeElement, {},
      (googleUser) => {
        let profile = googleUser.getBasicProfile();
        console.log('Token || ' + googleUser.getAuthResponse().id_token);
        console.log('Image URL: ' + profile.getImageUrl());
        console.log('Email: ' + profile.getEmail());
        
        alert('login successful');
        this.router.navigate(['product']);

      }, (error) => {
        alert(JSON.stringify(error, undefined, 2));
      });
  }
}