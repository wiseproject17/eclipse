import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agent-login',
  templateUrl: './agent-login.component.html',
  styleUrls: ['./agent-login.component.css']
})
export class AgentLoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
