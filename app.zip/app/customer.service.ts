import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { retry } from 'rxjs/operators';
import { Subject } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  private isUserLogged: any;
  cartItems = [];
  productToBeAdded: Subject<any>;
  constructor(private httpClient: HttpClient) {
    this.isUserLogged = false;
    this.productToBeAdded = new Subject();
   }
   setUserLoggedIn(): void { // login success
    this.isUserLogged = true;
   }
   setUserLoggedOut(): void { // logout success
    this.isUserLogged = false;
   }
   getUserLogged(): any { // call this in AuthGuard
     return this.isUserLogged;
   }

   getDistrictList(): any{
    return this.httpClient.get('https://restcountries.eu/rest/v2/all');
   }
   getStateList() : any{
    return this.httpClient.get('https://restcountries.eu/rest/v2/all');
   }

  registerCustomer(customer: any) {
    return this.httpClient.post('Artisanal/webapi/myresource/register/', customer);
  }
  getCustomerByUserPass(loginId : any, password: any) : any{
    return this.httpClient.get('Artisanal/webapi/myresource/getCustomerByUserPass/'+loginId+'/'+password);
  }
  getAgentByUserPass(loginId : any, password: any) : any{
    return this.httpClient.get('Artisanal/webapi/myresource/getAgentByUserPass/'+loginId+'/'+password);
  }
  postFile(ImageForm: any, fileToUpload: File) {
    // const endpoint='RESTAPI/webapi/myresource/';
    const formData: FormData = new FormData();
    formData.append('productName', ImageForm.proName);
    formData.append('price', ImageForm.price);
    formData.append('description', ImageForm.description);
    formData.append('Image', fileToUpload, fileToUpload.name);
    formData.append('Category', ImageForm.catName);
    formData.append('Quantity', ImageForm.quantity);

    return this.httpClient.post('Artisanal/webapi/myresource/registerProduct/', formData);
  }

  getProducts() {
    return this.httpClient.get('Artisanal/webapi/myresource/getProducts').pipe(retry(10));
  }
  addToCart(product: any) {
    this.productToBeAdded.next(product);
    this.cartItems.push(product);
    // localStorage.setItem('cartItems', JSON.stringify(this.cartItems));
  }
  getForCart() {
    return this.productToBeAdded.asObservable();
  }

}
