import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  private isUserLogged: any;
  constructor(private httpClient: HttpClient) {
    this.isUserLogged = false;
   }
   setUserLoggedIn(): void { // login success
    this.isUserLogged = true;
   }
   setUserLoggedOut(): void { // logout success
    this.isUserLogged = false;
   }
   getUserLogged(): any { // call this in AuthGuard
     return this.isUserLogged;
   }
  
   getDistrictList(): any{
    return this.httpClient.get('https://restcountries.eu/rest/v2/all');
   }
   getStateList() : any{
    return this.httpClient.get('https://restcountries.eu/rest/v2/all');
   }

   registerCustomer(customer: any) {
      return this.httpClient.post('Artisanal/webapi/myresource/register/', customer);
    }

    getCustomerByUserPass(loginId : any, password: any) : any{
      return this.httpClient.get('Artisanal/webapi/myresource/getCustomerByUserPass/'+loginId+'/'+password);
    }

}
