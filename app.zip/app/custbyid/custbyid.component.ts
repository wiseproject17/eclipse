import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-custbyid',
  templateUrl: './custbyid.component.html',
  styleUrls: ['./custbyid.component.css']
})
export class CustbyidComponent implements OnInit {
  customer : any;
  loginId: any;
  password: any;
  constructor(private service : CustomerService) { }

  ngOnInit() {
  }

  getCustById() {
    this.service.getCustomerByUserPass(this.loginId, this.password).subscribe((result: any) => {
      this.customer = result; 
      if(this.customer == null){
        console.log("false");
      }
      else{
        console.log("true");
      }
    });
  }
}
