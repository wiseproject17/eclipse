import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  product: any;
  constructor(private router: Router,private service: CustomerService) { 
    this.product = {proId: '', proName: '',price: '', description: '',proImage: '',catName: '',quantity:''};
  }
  ngOnInit() {
  }
  // registerProduct(): void {
  //   this.service.registerProduct(this.product).subscribe((result: any) => { console.log(result); } );
  //   console.log(this.product);
  //   alert('Product details updated Successfully');
  //   this.router.navigate(['home']);
  // }
}
