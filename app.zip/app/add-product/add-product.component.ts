import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  imageUrl: string;
  fileToUpload: File = null;
  reader: FileReader;
  product: any;
  constructor(private router: Router,private service: CustomerService) {
    this.imageUrl = '/assets/img/default-image.png';
  }
  ngOnInit() {
  }
  remove(){
    localStorage.removeItem('user');

  }
  /*registerProduct(): void {
    this.service.registerProduct(this.product).subscribe((result: any) => { console.log(result); } );
    console.log(this.product);
    alert('Product details updated Successfully');
    this.router.navigate(['agentProduct']);
  }
*/
  handleFileInput(file: FileList){
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    this.reader.readAsDataURL(this.fileToUpload);
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }
  OnSubmit(imageForm: any) {
    console.log(imageForm);
    this.service.postFile(imageForm, this.fileToUpload).subscribe (
      data => {
        console.log('done');
        this.imageUrl = '/assets/Images/recipe.jpg';
      }
    );
  }
}


  // handleFileInput(file: FileList) {
  //   this.fileToUpload = file.item(0);

  //   // Show image preview
  //   this.reader = new FileReader();
  //   this.reader.readAsDataURL(this.fileToUpload);
  //   this.reader.onload = (event: any) => {
  //     this.imageUrl = event.target.result;
  //   };
  // }

  // OnSubmit(imageForm: any) {
  //  this.service.postFile(imageForm, this.fileToUpload).subscribe(
  //    data => {
  //      console.log('done');
  //      this.imageUrl = '/assets/image/default.png';
  //    }
  //  );
  //

