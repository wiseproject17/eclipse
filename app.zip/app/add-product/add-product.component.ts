import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  product: any;
  constructor(private router: Router,private service: CustomerService) { 
    this.product = {proId: '', proName: '',price: '', description: '',proImage: '',catName: '',quantity:''};
  }
  ngOnInit() {
  }
  remove(){
    localStorage.removeItem('user');
    
  }
  registerProduct(): void {
    this.service.registerProduct(this.product).subscribe((result: any) => { console.log(result); } );
    console.log(this.product);
    alert('Product details updated Successfully');
    this.router.navigate(['home']);
  }

}
