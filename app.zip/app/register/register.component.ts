import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  district: any;
  state: any;
  customer: any;
  constructor(private service: CustomerService) {
    this.customer = {customerId: '', userName: '',emailId: '', password: '',phone: '',address: '', district: '',state:''
  
    };
  }

  ngOnInit() {
    this.service.getDistrictList().subscribe((data: any) => {console.log(data); this.district = data; });
    this.service.getStateList().subscribe((data: any) => {console.log(data); this.state = data; });
  }
  register(): void {
    this.service.registerCustomer(this.customer).subscribe((result: any) => { console.log(result); } );
    console.log(this.customer);
  }
}
