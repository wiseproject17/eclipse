import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { TestComponent } from './test/test.component';
import { LoginComponent } from './login/login.component';
import { ExperiencePipe } from './experience.pipe';
import { GenderPipe } from './gender.pipe';
import { MobilePipe } from './mobile.pipe';
import { RegisterComponent } from './register/register.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';

import { AuthGuard } from './auth.guard';
import { CustbyidComponent } from './custbyid/custbyid.component';

const appRoot: Routes = [{path: '', component: LoginComponent},
                         {path: 'login', component: LoginComponent},
                         {path: 'custbyid', component: CustbyidComponent},
                        {path: 'register', canActivate: [AuthGuard], component: RegisterComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    TestComponent,
    LoginComponent,
    ExperiencePipe,
    GenderPipe,
    MobilePipe,
    RegisterComponent,
    HeaderComponent,
    FooterComponent,
    CustbyidComponent,
  ],
  imports: [

BrowserModule, FormsModule, HttpClientModule, RouterModule.forRoot(appRoot)
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
