import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { TestComponent } from './test/test.component';
import { LoginComponent } from './login/login.component';
import { MobilePipe } from './mobile.pipe';
import { RegisterComponent } from './register/register.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';

import { AuthGuard } from './auth.guard';
import { HomeComponent } from './home/home.component';
import { ProductComponent } from './product/product.component';
import { AgentProductComponent } from './agent-product/agent-product.component';
import { AddProductComponent } from './add-product/add-product.component';
import { LogoutComponent } from './logout/logout.component';

const appRoot: Routes = [{path: '', component: LoginComponent},
                         {path: 'login', component: LoginComponent},
                         {path: 'product/home', component: HomeComponent},
                         {path: 'agentProduct/home', component: HomeComponent},
                         {path: 'agentProduct/addProduct', component: AddProductComponent},
                         {path: 'agentProduct/addProduct/agentProduct', component: AgentProductComponent},
                         {path: 'product', component: ProductComponent},
                         {path: 'addProduct', component: AddProductComponent},
                         {path: 'addProduct/login', component: LoginComponent},
                         {path: 'logout', component: LogoutComponent},
                         {path: 'agentProduct', component: AgentProductComponent},
                        {path: 'register', component: RegisterComponent}

];
@NgModule({
  declarations: [
    AppComponent,
    TestComponent,
    LoginComponent,
    MobilePipe,
    RegisterComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    ProductComponent,
    AgentProductComponent,
    AddProductComponent,
    LogoutComponent
  ],
  imports: [

BrowserModule, FormsModule, HttpClientModule, RouterModule.forRoot(appRoot)
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
