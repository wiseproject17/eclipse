import { MobilePipe } from './mobile.pipe';

describe('MobilePipe', () => {
  it('create an instance', () => {
    const pipe = new MobilePipe();
    expect(pipe).toBeTruthy();
  });
});
