import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentProductComponent } from './agent-product.component';

describe('AgentProductComponent', () => {
  let component: AgentProductComponent;
  let fixture: ComponentFixture<AgentProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
